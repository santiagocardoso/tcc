# set number of nodes
set opt(nn) 2614

# set activity file
set opt(af) $opt(config-path)
append opt(af) /activityTracerFinal.tcl

# set mobility file
set opt(mf) $opt(config-path)
append opt(mf) /mobiTracerFinal.tcl

# set start/stop time
set opt(start) 30600.0
set opt(stop) 31321.0

# set floor size
set opt(x) 8155.47
set opt(y) 8054.39
set opt(min-x) 4158.01
set opt(min-y) 6178.78

