# set number of nodes
set opt(nn) 527

# set activity file
set opt(af) $opt(config-path)
append opt(af) /activityTracerFinal.tcl

# set mobility file
set opt(mf) $opt(config-path)
append opt(mf) /mobiTracerFinal.tcl

# set start/stop time
set opt(start) 39600.0
set opt(stop) 40321.0

# set floor size
set opt(x) 10125.62
set opt(y) 8053.56
set opt(min-x) 4158.46
set opt(min-y) 4473.33

