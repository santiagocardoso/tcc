# set number of nodes
set opt(nn) 1332

# set activity file
set opt(af) $opt(config-path)
append opt(af) /activityTracerFinal.tcl

# set mobility file
set opt(mf) $opt(config-path)
append opt(mf) /mobiTracerFinal.tcl

# set start/stop time
set opt(start) 30600.0
set opt(stop) 31321.0

# set floor size
set opt(x) 4658.33
set opt(y) 9593.32
set opt(min-x) 1788.78
set opt(min-y) 6984.78

