# set number of nodes
set opt(nn) 454

# set activity file
set opt(af) $opt(config-path)
append opt(af) /activityTracerFinal.tcl

# set mobility file
set opt(mf) $opt(config-path)
append opt(mf) /mobiTracerFinal.tcl

# set start/stop time
set opt(start) 39600.0
set opt(stop) 40321.0

# set floor size
set opt(x) 4657.64
set opt(y) 9592.93
set opt(min-x) 1790.05
set opt(min-y) 6985.13

